package br.com.julio.pi.backoffice_users;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackofficeUsersApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackofficeUsersApplication.class, args);
	}

}
