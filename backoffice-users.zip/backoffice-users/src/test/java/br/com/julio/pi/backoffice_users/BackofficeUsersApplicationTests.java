package br.com.julio.pi.backoffice_users;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackofficeUsersApplicationTests {

	@Test
	void contextLoads() {
	}

}
