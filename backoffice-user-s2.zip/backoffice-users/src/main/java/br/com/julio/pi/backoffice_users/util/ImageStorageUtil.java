package br.com.julio.pi.backoffice_users.util;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.Instant;
import java.util.Locale;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ImageStorageUtil {

    private final Path baseDir;

    public ImageStorageUtil(@Value("${app.images.base-dir:imagens}") String baseDir) {
        this.baseDir = Paths.get(baseDir).toAbsolutePath().normalize();
    }

    /** Copia origem -> <baseDir>/<produtoId>/<nomeUnico.ext> e retorna caminho relativo gravável no banco. */
    public String copyForProduct(Long produtoId, String origemAbsoluta) throws IOException {
        if (produtoId == null) throw new IllegalArgumentException("produtoId é obrigatório");
        if (origemAbsoluta == null || origemAbsoluta.isBlank()) throw new IllegalArgumentException("Caminho de origem é obrigatório");

        Path src = Paths.get(origemAbsoluta);
        if (!Files.exists(src) || !Files.isReadable(src)) {
            throw new IOException("Arquivo origem não encontrado ou sem permissão: " + origemAbsoluta);
        }

        String ext = guessExtension(src.getFileName().toString());
        String nomeUnico = gerarNomeUnico(ext);

        Path pastaProduto = baseDir.resolve(String.valueOf(produtoId));
        Files.createDirectories(pastaProduto);

        Path destino = pastaProduto.resolve(nomeUnico);
        int tentativa = 0;
        while (Files.exists(destino) && tentativa < 3) {
            nomeUnico = gerarNomeUnico(ext);
            destino = pastaProduto.resolve(nomeUnico);
            tentativa++;
        }

        Files.copy(src, destino, StandardCopyOption.REPLACE_EXISTING);

        // Ex.: "imagens/5/123abc.jpg"
        Path relativo = baseDir.getFileName().resolve(String.valueOf(produtoId)).resolve(nomeUnico);
        return relativo.toString().replace('\\', '/');
    }

    private String gerarNomeUnico(String ext) {
        String base = Instant.now().toEpochMilli() + "-" + UUID.randomUUID().toString().substring(0, 8);
        return (ext == null || ext.isBlank()) ? base : base + "." + ext.toLowerCase(Locale.ROOT);
    }

    private String guessExtension(String filename) {
        int i = filename.lastIndexOf('.');
        return (i > 0 && i < filename.length() - 1) ? filename.substring(i + 1) : "";
    }
}
