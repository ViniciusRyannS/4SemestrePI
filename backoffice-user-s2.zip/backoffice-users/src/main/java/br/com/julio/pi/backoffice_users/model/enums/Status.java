package br.com.julio.pi.backoffice_users.model.enums;

public enum Status {
    ATIVO,
    INATIVO
}
